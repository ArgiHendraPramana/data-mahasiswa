<div class="container">
    <h1>Welcome To Our University</h1>
</div>
<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://unper.ac.id/wp-content/uploads/2022/12/Slider_01.jpg" class="d-block w-100" alt="10px">
    </div>
    <div class="carousel-item">
      <img src="https://1.bp.blogspot.com/-7xCKagdmlNw/YC9fJvmi9HI/AAAAAAAACJ4/MLkTB3ehcugXK1_sh108Ijo36slgorgnwCLcBGAsYHQ/s1152/gerbang%2Bunper.jpg" class="d-block w-100" alt="10px">
    </div>
    <div class="carousel-item">
      <img src="https://informatika.unper.ac.id/wp-content/uploads/sites/7/2022/04/pmb1-1400x524.png" class="d-block w-100" alt="10px">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>